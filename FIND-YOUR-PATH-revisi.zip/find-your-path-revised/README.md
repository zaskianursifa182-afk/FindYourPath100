# FIND YOUR PATH — Revised

## Menjalankan lokal
- Node.js 18+ diperlukan.
- Jalankan `npm start`
- Buka `http://localhost:3000`

## Deploy Railway
Upload seluruh isi folder ke GitHub, hubungkan repository ke Railway, lalu deploy.
Railway akan menjalankan `npm start` dan server otomatis memakai `process.env.PORT`.

## Mengaktifkan AI Pathmate
AI chat memakai OpenAI Responses API melalui server agar API key tidak terekspos di browser.
Di Railway → service → Variables, tambahkan:
- `OPENAI_API_KEY` = API key milik pemilik project
- `OPENAI_MODEL` = `gpt-6-luna` (opsional; bisa diganti model yang tersedia di akun)

Tanpa API key, Pathmate tetap menyediakan mode panduan lokal sederhana. Penggunaan API dapat dikenakan biaya sesuai tarif akun API; ChatGPT berlangganan tidak otomatis mencakup kredit API.

## Penyimpanan
Tidak memakai database. Profil, hasil tes, target, favorit, dan jurnal disimpan di LocalStorage browser. Data tidak tersinkron antarperangkat.

## Catatan akurasi
- Assessment berisi 36 item dan memberi gambaran minat, bukan diagnosis.
- Persentase kecocokan jurusan/profesi adalah skor kecocokan kategori minat sederhana, bukan probabilitas keberhasilan.
- Modul PTN hanya memberi indikator kesiapan berdasarkan input. Bukan persentase peluang diterima. Gunakan data resmi SNPMB untuk daya tampung dan persaingan.
- Label tren karier merupakan kategori indikatif, bukan angka lowongan realtime.
