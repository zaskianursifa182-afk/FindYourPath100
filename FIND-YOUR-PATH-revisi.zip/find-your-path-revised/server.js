const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const HOST = "0.0.0.0";
const PUBLIC_DIR = path.join(__dirname, "public");
const MIME = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"application/javascript; charset=utf-8", ".json":"application/json; charset=utf-8", ".png":"image/png", ".jpg":"image/jpeg", ".svg":"image/svg+xml" };

function send(res, status, data) {
  res.writeHead(status, {"Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store"});
  res.end(JSON.stringify(data));
}
const server = http.createServer(async (req,res) => {
  if (req.method === "POST" && req.url === "/api/chat") {
    if (!process.env.OPENAI_API_KEY) return send(res,503,{error:"AI belum dikonfigurasi"});
    let body="";
    req.on("data",chunk=>{ body+=chunk; if(body.length>20000) req.destroy(); });
    req.on("end",async()=>{
      try {
        const data=JSON.parse(body);
        if(typeof data.message!=="string" || !data.message.trim()) return send(res,400,{error:"Pesan kosong"});
        const history=Array.isArray(data.history)?data.history.slice(-8):[];
        const safeHistory=history.filter(x=>["user","assistant"].includes(x.role)&&typeof x.content==="string").map(x=>({role:x.role,content:x.content.slice(0,2000)}));
        const context = `Kamu adalah Pathmate, pendamping eksplorasi minat, pendidikan, dan karier untuk pelajar di Indonesia. Jawab dalam bahasa Indonesia yang ramah, jelas, suportif, tidak menghakimi, dan sesuai usia remaja. Jangan meminta data pribadi sensitif. Jangan mengklaim tes minat sebagai diagnosis atau kepastian. Untuk peluang PTN/kerja, jelaskan keterbatasan data dan arahkan ke sumber resmi; jangan mengarang angka. Profil ringkas: ${JSON.stringify({level:data.profile?.level||"",interests:data.profile?.interests||"",riasec:data.result||[]})}`;
        const response=await fetch("https://api.openai.com/v1/responses",{
          method:"POST",
          headers:{"Authorization":`Bearer ${process.env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
          body:JSON.stringify({model:process.env.OPENAI_MODEL||"gpt-6-luna",instructions:context,input:[...safeHistory,{role:"user",content:data.message.slice(0,3000)}],max_output_tokens:650})
        });
        const result=await response.json();
        if(!response.ok) return send(res,502,{error:result.error?.message||"Layanan AI tidak dapat dihubungi"});
        const reply=result.output?.flatMap(item=>item.content||[]).filter(part=>part.type==="output_text").map(part=>part.text).join("\n")||"Maaf, aku belum bisa menyusun jawaban. Coba lagi ya.";
        return send(res,200,{reply});
      } catch(err) { return send(res,500,{error:"Terjadi kesalahan pada layanan AI"}); }
    });
    return;
  }
  if(req.method!=="GET" && req.method!=="HEAD"){res.writeHead(405);return res.end("Method Not Allowed");}
  let pathname;
  try { pathname=decodeURIComponent((req.url||"/").split("?")[0]); } catch {res.writeHead(400);return res.end("Bad Request");}
  if(pathname==="/") pathname="/index.html";
  const file=path.resolve(PUBLIC_DIR,"."+pathname);
  if(!file.startsWith(PUBLIC_DIR+path.sep)){res.writeHead(403);return res.end("Forbidden");}
  fs.stat(file,(err,stats)=>{
    if(err||!stats.isFile()){res.writeHead(404);return res.end("Not Found");}
    res.writeHead(200,{"Content-Type":MIME[path.extname(file)]||"application/octet-stream","X-Content-Type-Options":"nosniff"});
    if(req.method==="HEAD")return res.end();
    fs.createReadStream(file).pipe(res);
  });
});
server.listen(PORT,HOST,()=>console.log(`FIND YOUR PATH ready on port ${PORT}`));
